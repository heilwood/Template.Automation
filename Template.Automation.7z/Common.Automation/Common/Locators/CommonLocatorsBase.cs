﻿namespace Common.Automation.Common.Locators
{
    public class CommonLocatorsBase
    {
        

    }
}
