﻿using Common.Automation.Common.Actions.ElementsBase;
using OpenQA.Selenium;

namespace Common.Automation.Common.Actions
{
    public class Tab : ClickElementBase
    {
        public Tab(IWebDriver driver) : base(driver)
        {
        }
    }
}
