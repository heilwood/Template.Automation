﻿using Common.Automation.Common.Actions.ElementsBase;
using OpenQA.Selenium;

namespace Common.Automation.Common.Actions
{
    public class Radio : ClickElementBase
    {
        public Radio(IWebDriver driver) : base(driver)
        {
        }
    }
}
