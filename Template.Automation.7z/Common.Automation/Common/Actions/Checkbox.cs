﻿using Common.Automation.Common.Actions.ElementsBase;
using OpenQA.Selenium;

namespace Common.Automation.Common.Actions
{
    public class Checkbox : ClickElementBase
    {
        public Checkbox(IWebDriver driver) : base(driver)
        {
        }
    }
}
