﻿using Common.Automation.Common.Actions.ElementsBase;
using OpenQA.Selenium;

namespace Common.Automation.Common.Actions
{
    public class Button : ClickElementBase
    {
        public Button(IWebDriver driver) : base(driver)
        {
        }
    }
}
