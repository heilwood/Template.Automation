﻿using Common.Automation.Common.Actions.ElementsBase;
using OpenQA.Selenium;

namespace Common.Automation.Common.Actions
{
    public class DatePicker : InputElementBase
    {
        public DatePicker(IWebDriver driver) : base(driver)
        {
        }
    }
}
