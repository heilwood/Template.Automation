﻿using Common.Automation.Common.Actions.ElementsBase;
using OpenQA.Selenium;

namespace Common.Automation.Common.Actions
{
    public class TextElement : TextElementBase
    {
        public TextElement(IWebDriver driver) : base(driver)
        {
        }
    }
}
