﻿using OpenQA.Selenium;

namespace Common.Automation.Common.Browser
{
    public interface IBrowserSettings
    {
        DriverOptions GetBrowserSettings();
    }
}
