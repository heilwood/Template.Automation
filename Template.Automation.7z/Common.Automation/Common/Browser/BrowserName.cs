﻿namespace Common.Automation.Common.Browser
{
    public enum BrowserName
    {
        Unknown = 0,
        Firefox = 1,
        Chrome = 2
    }
}
