﻿namespace Common.Automation
{
    public class ConfigManager
    {
        public static int WaitTime = 15;
        public static string BrowserName = "Chrome";
        public static int PageLoadWaitTime = 50;
        public static string MainUrl = "https://www.google.com";
    }
}
