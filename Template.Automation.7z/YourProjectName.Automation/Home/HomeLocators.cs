﻿namespace YourProjectName.Automation.Home
{
    public class HomeLocators
    {

    }
}
